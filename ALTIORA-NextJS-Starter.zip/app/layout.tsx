
export default function RootLayout({children}:{children:React.ReactNode}){
  return (
    <html lang="pt-BR">
      <body style={{margin:0,fontFamily:'Inter, Arial, sans-serif',background:'#050B18',color:'#fff'}}>
        {children}
      </body>
    </html>
  )
}
