
export default function Home(){
  return (
    <main>
      <section style={{padding:'120px 24px',maxWidth:1200,margin:'0 auto'}}>
        <div style={{color:'#2CEAA3',fontWeight:700}}>ALTIORA GROWTH PLATFORM</div>
        <h1 style={{fontSize:'64px',lineHeight:1.05,maxWidth:900}}>
          Construa uma rede de performance e escale suas operações comerciais.
        </h1>
        <p style={{maxWidth:700,color:'#9aa4b2',fontSize:'20px'}}>
          Plataforma premium para gestão de parceiros, comissões inteligentes e crescimento sustentável.
        </p>
        <div style={{display:'flex',gap:12,marginTop:24}}>
          <button style={{padding:'14px 24px',borderRadius:12,border:0,background:'#2CEAA3'}}>Começar Agora</button>
          <button style={{padding:'14px 24px',borderRadius:12,background:'transparent',color:'#fff',border:'1px solid #334'}}>Ver Demonstração</button>
        </div>
      </section>

      <section style={{padding:'40px 24px 120px',maxWidth:1200,margin:'0 auto'}}>
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(240px,1fr))',gap:20}}>
          {['Comissões Inteligentes','Dashboard Executivo','Relatórios em Tempo Real','Compliance'].map(item=>(
            <div key={item} style={{border:'1px solid #223',borderRadius:20,padding:24,background:'rgba(255,255,255,.03)'}}>
              <h3>{item}</h3>
              <p style={{color:'#9aa4b2'}}>Estrutura premium pronta para expansão.</p>
            </div>
          ))}
        </div>
      </section>
    </main>
  )
}
